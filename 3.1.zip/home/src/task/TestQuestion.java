package task;

public class TestQuestion extends Task {
    private String question;
    private String expectedAnswer;

    public TestQuestion(String question, String expectedAnswer) {
        this.question = question;
        this.expectedAnswer = expectedAnswer;
    }

    public String getQuestion() {
        return question;
    }

    public boolean checkAnswer(String answer) {
        return answer.equalsIgnoreCase(expectedAnswer);
    }
}
