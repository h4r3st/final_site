package task;

public abstract class Task {
    public abstract String getQuestion();

    public abstract boolean checkAnswer(String answer);
}
