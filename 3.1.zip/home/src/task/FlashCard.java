package task;

public class FlashCard extends Task {
    private String question;
    private String expectedAnswer;

    public FlashCard(String question, String expectedAnswer) {
        this.question = question;
        this.expectedAnswer = expectedAnswer;
    }

    public String getQuestion() {
        return question;
    }

    public boolean checkAnswer(String answer) {
        return answer.equalsIgnoreCase(expectedAnswer);
    }
}
