import task.Task;
import task.FlashCard;

import task.TestQuestion;

import java.util.Scanner;
import java.util.List;


public class App {
    public static void main(String[] args) {

        List<Task> tasks = new java.util.ArrayList<>();
        tasks.add(new FlashCard("Столица Германии?", "Берлин"));
        tasks.add(new TestQuestion("3 * 3 = ", "9"));
        LearningHelper helper = new LearningHelper(tasks);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            Task task = helper.nextTask();
            if (task == null)
                break;

            System.out.println("Вопрос: " + task.getQuestion());
            System.out.print("Ваш ответ: ");
            String answer = scanner.nextLine();

            System.out.println(task.checkAnswer(answer) ? "Верный ответ" : "Ответ неверен");

        }

        System.out.println("Вы ответили на все вопросы!");
        scanner.close();
    }
}