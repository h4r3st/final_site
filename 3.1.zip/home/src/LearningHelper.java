import task.Task;

import java.util.List;

public class LearningHelper {
    private List<Task> tasks; 
    private int currentTaskIndex = 0;

    public LearningHelper(List<Task> tasks) { 
        this.tasks = tasks;
    }

    public Task nextTask() {
        if (currentTaskIndex < tasks.size()) {
            return tasks.get(currentTaskIndex++);
        }
        return null; 
    }
}