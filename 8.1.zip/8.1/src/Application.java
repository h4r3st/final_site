import java.io.IOException;

public class Application {
  public static void main(String[] args) throws IOException {
    // new FileStructureGenerator().generate();
    new RecursiveDirRemover().deleteDir("hw");
  }
}
