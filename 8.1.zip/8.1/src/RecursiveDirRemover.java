import java.io.File;

public class RecursiveDirRemover {
  public void deleteDir(String dirPath) {
    File directory = new File(dirPath);
    if (!directory.exists()) {
      return;
    }

    File[] files = directory.listFiles();
    if (files != null) {
      for (File file : files) {
        if (file.isDirectory()) {
          deleteDir(file.getAbsolutePath());
        } else {
          file.delete();
        }
      }
    }

    directory.delete();
  }
}
