import java.io.File;
import java.io.IOException;

public class FileStructureGenerator {
  public void generate() throws IOException {
    new File("hw/dir_1/dir_1_1").mkdirs();
    new File("hw/dir_1/dir_1_2/dir_1_2_1").mkdirs();
    new File("hw/dir_1/dir_1_1/ex_1_1.txt").createNewFile();
    new File("hw/ex.txt").createNewFile();
    new File("hw/dir_1/dir_1_2/ex_1_2.txt").createNewFile();
    new File("hw/dir_1/dir_1_2/ex_1_2.txt").createNewFile();
    new File("hw/dir_1/dir_1_2/dir_1_2_1/ex_1_2_1.txt").createNewFile();
    new File("hw/dir_1/dir_1_2/dir_1_2_1/ex_1_2_2.txt").createNewFile();
    new File("hw/dir_1/dir_1_2/dir_1_2_1/ex_1_2_3.txt").createNewFile();
  }
}
