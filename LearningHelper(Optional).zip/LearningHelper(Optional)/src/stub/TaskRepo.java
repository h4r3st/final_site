package stub;

import java.util.List;
import java.util.Optional;

import task.Task;

public interface TaskRepo {
    List<Task> findAll();

    Optional<Task> findById(Long id);

    Task create(Task task);

    Optional<Task> update(Task task);

    void delete(Long id);
}