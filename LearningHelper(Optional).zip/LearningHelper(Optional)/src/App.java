import java.util.Scanner;
import stub.StubTaskRepo;
import task.Task;
import java.util.Optional;

public class App {
    public static void main(String[] args) {
        LearningHelper helper = LearningHelper.getInstance(new StubTaskRepo());
        Scanner scanner = new Scanner(System.in);

        while (helper.hasNextTask()) {
            Optional<Task> taskOptional = helper.nextTask();
            taskOptional.ifPresent(task -> {
                System.out.println(task.getQuestion());
                System.out.print("Ответ: ");
                String answer = scanner.nextLine();

                System.out.println(
                        task.checkAnswer(answer)
                                ? "Верно!"
                                : "Неверно!");
            });
        }
        System.out.println("Вы ответили на все вопросы!");
        scanner.close();
    }
}