package task;

public class FlashCard implements Task {
    private Long id;
    private final String question;
    private final String expectedAnswer;

    private FlashCard(Builder builder) {
        this.id = builder.id;
        this.question = builder.question;
        this.expectedAnswer = builder.expectedAnswer;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String getQuestion() {
        return question;
    }

    @Override
    public boolean checkAnswer(String answer) {
        return answer.equalsIgnoreCase(expectedAnswer);
    }

    public static class Builder {
        private Long id;
        private String question;
        private String expectedAnswer;

        public Builder setQuestion(String question) {
            this.question = question;
            return this;
        }

        public Builder setExpectedAnswer(String expectedAnswer) {
            this.expectedAnswer = expectedAnswer;
            return this;
        }

        public Builder setId(Long id) {
            this.id = id;
            return this;
        }

        public FlashCard build() {
            if (question == null || expectedAnswer == null) {
                throw new IllegalStateException("Необходимо ввести вопрос и ответ на него");
            }
            return new FlashCard(this);
        }
    }
}