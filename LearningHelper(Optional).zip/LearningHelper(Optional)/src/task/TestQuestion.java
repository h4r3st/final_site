package task;

import java.util.Map;

public class TestQuestion implements Task {
    private Long id;
    private final String question;
    private final Map<String, Boolean> answers;

    private TestQuestion(Builder builder) {
        this.id = builder.id;
        this.question = builder.question;
        this.answers = builder.answers;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String getQuestion() {
        StringBuilder sb = new StringBuilder(question + "\nВарианты ответа:");
        for (String option : answers.keySet()) {
            sb.append("\n- ").append(option);
        }
        return sb.toString();
    }

    @Override
    public boolean checkAnswer(String answer) {
        return answers.getOrDefault(answer, false);
    }

    public static class Builder {
        private Long id;
        private String question;
        private Map<String, Boolean> answers;

        public Builder setQuestion(String question) {
            this.question = question;
            return this;
        }

        public Builder setAnswers(Map<String, Boolean> answers) {
            this.answers = answers;
            return this;
        }

        public Builder setId(Long id) {
            this.id = id;
            return this;
        }

        public TestQuestion build() {
            if (question == null || answers == null) {
                throw new IllegalStateException("Необходимо ввести вопрос и ответ на него");
            }
            return new TestQuestion(this);
        }
    }

}