package task;

public interface Task {
    Long getId();

    void setId(Long id);

    String getQuestion();

    boolean checkAnswer(String answer);
}
