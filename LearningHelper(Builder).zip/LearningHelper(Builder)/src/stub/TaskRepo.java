package stub;

import java.util.List;

import task.Task;

public interface TaskRepo {
    List<Task> findAll();

    Task findById(Long id);

    Task create(Task task);

    Task update(Task task);

    void delete(Long id);
}