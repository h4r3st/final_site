package stub;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import task.FlashCard;
import task.Task;
import task.TestQuestion;

public class StubTaskRepo implements TaskRepo {
    private final Map<Long, Task> tasks = new HashMap<>();
    private Long maxIndex = 0L;

    public StubTaskRepo() {

        Task task1 = new FlashCard.Builder()
                .setQuestion("Столица Германии?")
                .setExpectedAnswer("Берлин")
                .setId(1L)
                .build();

        Map<String, Boolean> answers = new HashMap<>();
        answers.put("25", true);
        answers.put("20", false);

        Task task2 = new TestQuestion.Builder()
                .setQuestion("5 * (3 + 2)")
                .setAnswers(answers)
                .setId(2L)
                .build();

        tasks.put(1L, task1);
        tasks.put(2L, task2);
    }

    @Override
    public List<Task> findAll() {
        return new ArrayList<>(tasks.values());
    }

    @Override
    public Task findById(Long id) {
        return tasks.get(id);
    }

    @Override
    public Task create(Task task) {
        task.setId(++maxIndex);
        tasks.put(maxIndex, task);
        return task;
    }

    @Override
    public Task update(Task task) {
        if (tasks.containsKey(task.getId())) {
            tasks.put(task.getId(), task);
            return task;
        }
        return null;
    }

    @Override
    public void delete(Long id) {
        tasks.remove(id);
    }
}
