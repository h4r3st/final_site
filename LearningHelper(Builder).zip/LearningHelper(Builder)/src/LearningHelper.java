import java.util.List;

import stub.TaskRepo;
import task.Task;

public class LearningHelper {
    private static LearningHelper instance;
    private final TaskRepo taskRepo;
    private List<Task> tasks;
    private int currentTaskIndex = 0;

    private LearningHelper(TaskRepo taskRepo) {
        this.taskRepo = taskRepo;
        load();
    }

    public static LearningHelper getInstance(TaskRepo taskRepo) {
        if (instance == null) {
            instance = new LearningHelper(taskRepo);
        }
        return instance;
    }

    private void load() {
        tasks = taskRepo.findAll();
    }

    public boolean hasNextTask() {
        return currentTaskIndex < tasks.size();
    }

    public Task nextTask() {
        return hasNextTask() ? tasks.get(currentTaskIndex++) : null;
    }
}