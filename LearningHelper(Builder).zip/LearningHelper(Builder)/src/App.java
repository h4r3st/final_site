import java.util.Scanner;
import stub.StubTaskRepo;
import task.Task;

public class App {
    public static void main(String[] args) {
        LearningHelper helper = LearningHelper.getInstance(new StubTaskRepo());
        Scanner scanner = new Scanner(System.in);

        while (helper.hasNextTask()) {
            Task task = helper.nextTask();
            System.out.println(task.getQuestion());
            System.out.print("Ответ: ");
            String answer = scanner.nextLine();

            System.out.println(
                    task.checkAnswer(answer)
                            ? "Верно!"
                            : "Неверно!");
        }
        System.out.println("Вы овтетили на все вопросы!");
        scanner.close();
    }
}